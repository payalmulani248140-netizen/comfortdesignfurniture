document.querySelectorAll('header-menu details').forEach(details => {
  const summary = details.querySelector('summary');

  // Hover open
  details.addEventListener('mouseenter', () => {
    details.setAttribute('open', '');
  });

  // Hover close
  details.addEventListener('mouseleave', () => {
    details.removeAttribute('open');
  });

  // Click handling
  summary.addEventListener('click', (e) => {
    const link = summary.dataset.href;

    // If summary has data-href → redirect
    if (link) {
      window.location.href = link;
      return;
    }

    // No link → prevent toggle
    e.preventDefault();
  });
});
